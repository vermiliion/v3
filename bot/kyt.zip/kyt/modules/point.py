from kyt import *
import subprocess

@bot.on(events.CallbackQuery(data=b'point'))
async def point(event):
    async def point_(event):
        chat = event.chat_id
        sender = await event.get_sender()

        # Mengambil input subdomain dari pengguna
        await event.respond("**Masukkan Subdomain:**")
        subdomain_event = await bot.wait_for(events.NewMessage(incoming=True, from_users=sender.id))
        subdomain = subdomain_event.raw_text.strip()

        await event.respond("**Masukkan NS Domain:**")
        ns_domain_event = await bot.wait_for(events.NewMessage(incoming=True, from_users=sender.id))
        ns_domain = ns_domain_event.raw_text.strip()

        await event.edit("Processing...")

        # Menyusun skrip Bash
        script = f"""#!/bin/bash
apt install jq curl -y
rm -rf /root/xray/scdomain
mkdir -p /root/xray
clear
DOMAIN=vpnlite.cloud
SUB_DOMAIN={subdomain}
NS_DOMAIN={ns_domain}
CF_ID=bukanhanyaklik@gmail.com  # Ganti dengan email Cloudflare Anda
CF_KEY=99a7300e16ffd81ecd1331e8f92d92ceb309c  # Ganti dengan kunci API Cloudflare Anda
set -euo pipefail
IP=$(curl -sS ifconfig.me)
echo "Updating DNS for ${SUB_DOMAIN}..."
ZONE=$(curl -sLX GET "https://api.cloudflare.com/client/v4/zones?name=${DOMAIN}&status=active" \
-H "X-Auth-Email: ${CF_ID}" \
-H "X-Auth-Key: ${CF_KEY}" \
-H "Content-Type: application/json" | jq -r .result[0].id)

if [[ -z "$ZONE" ]]; then
    echo "Error: Zone not found for domain $DOMAIN."
    exit 1
fi

RECORD=$(curl -sLX GET "https://api.cloudflare.com/client/v4/zones/${ZONE}/dns_records?name=${SUB_DOMAIN}" \
-H "X-Auth-Email: ${CF_ID}" \
-H "X-Auth-Key: ${CF_KEY}" \
-H "Content-Type: application/json" | jq -r .result[0].id)

if [[ -z "$RECORD" ]]; then
    echo "Creating new A record for ${SUB_DOMAIN}..."
    RECORD=$(curl -sLX POST "https://api.cloudflare.com/client/v4/zones/${ZONE}/dns_records" \
    -H "X-Auth-Email: ${CF_ID}" \
    -H "X-Auth-Key: ${CF_KEY}" \
    -H "Content-Type: application/json" \
    --data '{{"type":"A","name":"{subdomain}","content":"{IP}","ttl":120,"proxied":false}}' | jq -r .result.id)
else
    echo "Updating existing A record for ${SUB_DOMAIN}..."
    RESULT=$(curl -sLX PUT "https://api.cloudflare.com/client/v4/zones/${ZONE}/dns_records/${RECORD}" \
    -H "X-Auth-Email: ${CF_ID}" \
    -H "X-Auth-Key: ${CF_KEY}" \
    -H "Content-Type: application/json" \
    --data '{{"type":"A","name":"{subdomain}","content":"{IP}","ttl":120,"proxied":false}}')
fi

echo "Updating DNS NS for ${NS_DOMAIN}..."
RECORD_NS=$(curl -sLX GET "https://api.cloudflare.com/client/v4/zones/${ZONE}/dns_records?name=${NS_DOMAIN}" \
-H "X-Auth-Email: ${CF_ID}" \
-H "X-Auth-Key: ${CF_KEY}" \
-H "Content-Type: application/json" | jq -r .result[0].id)

if [[ -z "$RECORD_NS" ]]; then
    echo "Creating new NS record for ${NS_DOMAIN}..."
    RECORD_NS=$(curl -sLX POST "https://api.cloudflare.com/client/v4/zones/${ZONE}/dns_records" \
    -H "X-Auth-Email: ${CF_ID}" \
    -H "X-Auth-Key: ${CF_KEY}" \
    -H "Content-Type: application/json" \
    --data '{{"type":"NS","name":"{ns_domain}","content":"{subdomain}","ttl":120,"proxied":false}}' | jq -r .result.id)
else
    echo "Updating existing NS record for ${NS_DOMAIN}..."
    RESULT=$(curl -sLX PUT "https://api.cloudflare.com/client/v4/zones/${ZONE}/dns_records/${RECORD_NS}" \
    -H "X-Auth-Email: ${CF_ID}" \
    -H "X-Auth-Key: ${CF_KEY}" \
    -H "Content-Type: application/json" \
    --data '{{"type":"NS","name":"{ns_domain}","content":"{subdomain}","ttl":120,"proxied":false}}')
fi

echo "Host : $SUB_DOMAIN"
echo "Host NS : $NS_DOMAIN"
echo "IP=$SUB_DOMAIN" > /var/lib/SIJA/ipvps.conf
echo "$SUB_DOMAIN" > /root/domain
echo "$NS_DOMAIN" > /root/nsdomain
echo "$SUB_DOMAIN" > /etc/xray/domain
echo "$SUB_DOMAIN" > /etc/v2ray/domain
echo "$SUB_DOMAIN" > /root/scdomain
echo "$SUB_DOMAIN" > /root/xray/scdomain

echo -e "Done Record Domain= $SUB_DOMAIN"
echo -e "Done Record NSDomain= $NS_DOMAIN"
        """

        # Menjalankan skrip Bash
        try:
            process = subprocess.run(["bash", "-c", script], capture_output=True, text=True)
            output = process.stdout if process.returncode == 0 else process.stderr
            await event.respond(f"**Output:**\n```\n{output}\n```")
        except Exception as e:
            await event.respond(f"**Error executing script:**\n```\n{str(e)}\n```")

    a = valid(str(sender.id))
    if a == "true":
        await point_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)
